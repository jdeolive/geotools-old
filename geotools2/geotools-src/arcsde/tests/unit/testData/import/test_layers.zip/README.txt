Use ArcCatalog or the following SDE command lines to
import these shapefiles into your ArcSDE database:
(cd to testData/import directory or wherever you had
 uncompressed the shapefiles)

 -- to import the point test data, in a single line (do not include the "\"'s):
   shp2sde -o create -f TEST_POINT.shp -l TEST_POINT,SHAPE -a all \
   -S "ArcSDE DataSource test point data" -i <service> -s <server> \
   -D <dbname> -u <dbuser> -p <dbpasswd>

 -- to import the line test data, in a single line (do not include the "\"'s):
   shp2sde -o create -f TEST_LINE.shp -l TEST_LINE,SHAPE -a all \
   -S "ArcSDE DataSource test line data" -i <service> -s <server> \
   -D <dbname> -u <dbuser> -p <dbpasswd>

 -- to import the polygon test data, in a single line (do not include the "\"'s):
   shp2sde -o create -f TEST_POLY.shp -l TEST_POLY,SHAPE -a all \
   -S "ArcSDE DataSource test line data" -i <service> -s <server> \
   -D <dbname> -u <dbuser> -p <dbpasswd>

 In all cases:
 <service>: by default 'esri_sde', is the esri sde's service name as
 declared in services file (<WINNT_DIR>/system32/Drivers/etc/Services in WinXX)
 <server>: ArcSDE server name
 <dbname>: SDE database name
 <dbuser>: SDE database user name
 <dbpasswd>: SDE database user password

